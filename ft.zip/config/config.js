export const ICE_SERVERS = [
  { urls: ['stun:stun.l.google.com:19302'] }, // временно
  // позже: свой TURN
  // { urls: 'turns:turn.example.com:5349', username: 'user', credential: 'pass' }
];